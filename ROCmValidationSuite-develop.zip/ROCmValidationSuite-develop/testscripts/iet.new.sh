echo 'iet_1';sudo ./rvs -c conf/iet_1.conf -d 3 && date
echo 'iet_2';sudo ./rvs -c conf/iet_2.conf -d 3 && date
echo 'iet_3';sudo ./rvs -c conf/iet_3.conf -d 3 && date
echo 'iet_4';sudo ./rvs -c conf/iet_4.conf -d 3 && date
echo 'iet_5';sudo ./rvs -c conf/iet_5.conf -d 3 && date
echo 'iet_6';sudo ./rvs -c conf/iet_6.conf -d 3 && date
